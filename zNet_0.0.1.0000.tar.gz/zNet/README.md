# Aim
just for me to analyses the sub study of ABCD study.

# plan
use the factor analyses to extract feature to following modeling.
